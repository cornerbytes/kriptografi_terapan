Tool ini telah dimodifikasi untuk membaut ca menggunakan openssl.
Credit to : https://github.com/yogi-ra untuk membuat base config dan tool automation
